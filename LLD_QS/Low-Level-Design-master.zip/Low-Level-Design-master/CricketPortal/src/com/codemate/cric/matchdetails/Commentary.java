package com.codemate.cric.matchdetails;


import java.util.Date;

import com.codemate.cric.users.Commentator;

public class Commentary {
	private String text;
	private Date createdAt;
	private Commentator createdBy;
}