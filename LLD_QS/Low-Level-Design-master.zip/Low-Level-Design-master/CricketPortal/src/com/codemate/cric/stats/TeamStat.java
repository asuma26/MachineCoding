package com.codemate.cric.stats;

public class TeamStat extends Stat{
	@Override
	public void saveStat() {
		// TODO Auto-generated method stub
		
	}
}
