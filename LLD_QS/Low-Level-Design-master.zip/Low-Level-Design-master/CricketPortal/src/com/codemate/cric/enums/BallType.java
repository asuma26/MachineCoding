package com.codemate.cric.enums;

public enum BallType {
	  NORMAL,
	  WIDE,
	  WICKET,
	  NO_BALL
}
