package com.codemate.cric.teamdetails;

import java.util.List;

import com.codemate.cric.users.Player;

public class TournamentSquad {
	  private List<Player> players;
	  private List<TournamentStat> tournamentStats;

	  public boolean addPlayer(Player player);
}
