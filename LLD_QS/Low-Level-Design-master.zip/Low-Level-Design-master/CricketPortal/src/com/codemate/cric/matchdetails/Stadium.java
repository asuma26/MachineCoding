package com.codemate.cric.matchdetails;

import com.codemate.cric.datatypes.Address;

public class Stadium {
	
	private String stadiumName;
	private Address location;

}
