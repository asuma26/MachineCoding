package com.codemate.cric.stats;

public class MatchStat extends Stat {
	@Override
	public void saveStat() {
		// TODO Auto-generated method stub

	}
}
