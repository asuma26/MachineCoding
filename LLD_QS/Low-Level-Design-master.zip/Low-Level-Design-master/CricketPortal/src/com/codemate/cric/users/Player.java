package com.codemate.cric.users;

import java.util.ArrayList;

import com.codemate.cric.datatypes.Person;

public class Player {
	
	  private Person person;
	  private ArrayList<PlayerContract> contracts;

	  /**
	   * Add contract to the player
	   * */
	  public boolean addContract() {
		  
	  }
}
