package com.codemate.cric.users;

import com.codemate.cric.datatypes.Person;


public class Referee {
	private Person person;	
	public boolean assignMatch(Match match) {
		
	}
}
