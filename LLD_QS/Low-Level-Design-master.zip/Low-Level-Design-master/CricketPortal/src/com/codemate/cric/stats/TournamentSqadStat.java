package com.codemate.cric.stats;

public class TournamentSqadStat extends Stat{

	@Override
	public void saveStat() {
		// TODO Auto-generated method stub
		
	}
	
}