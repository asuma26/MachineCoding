package com.codemate.cric.users;

import com.codemate.cric.datatypes.Person;

public class Admin {
	private Person person;

	public boolean addMatch(Match match) {

	}

	public boolean addTeam(Team team) {

	}

	public boolean addTournament(Tournament tournament) {

	}
}
