package com.codemate.cric.enums;

public enum MatchFormat {
	  ODI,
	  T20,
	  TEST
}
