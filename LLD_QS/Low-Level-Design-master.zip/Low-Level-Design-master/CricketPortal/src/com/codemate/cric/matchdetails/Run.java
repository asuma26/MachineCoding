package com.codemate.cric.matchdetails;

import com.codemate.cric.enums.RunType;

public class Run {
	
	private int numberOfRuns;
	private RunType runtype;

}
