package com.codemate.cric.users;

public class Umpire {
	private Person person;

	public boolean assignMatch(Match match);
}