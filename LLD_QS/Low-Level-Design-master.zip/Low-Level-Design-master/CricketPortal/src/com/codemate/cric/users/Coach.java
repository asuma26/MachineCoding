package com.codemate.cric.users;

import com.codemate.cric.datatypes.Person;

public class Coach {
	private Person person;
	
}
