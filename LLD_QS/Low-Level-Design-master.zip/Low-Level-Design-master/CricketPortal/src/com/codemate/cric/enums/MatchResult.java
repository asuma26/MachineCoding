package com.codemate.cric.enums;

public enum MatchResult {
	  LIVE,
	  FINISHED,
	  DRAWN,
	  CANCELED
}
