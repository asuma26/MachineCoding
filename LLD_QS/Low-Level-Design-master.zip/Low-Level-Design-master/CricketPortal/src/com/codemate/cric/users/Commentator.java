package com.codemate.cric.users;

import com.codemate.cric.datatypes.Person;
import com.codemate.cric.matchdetails.Match;

public class Commentator {
	private Person person;
	public boolean assignMatch(Match match) {
		
	}
}