package com.codemate.cric.enums;

public enum UmpireType {
	  FIELD,
	  RESERVED,
	  TV,
	  THIRD
}
