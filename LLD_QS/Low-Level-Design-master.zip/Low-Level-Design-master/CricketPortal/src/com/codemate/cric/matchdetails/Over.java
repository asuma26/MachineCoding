package com.codemate.cric.matchdetails;

import java.util.List;

public class Over {
	private int number;
	private List<Ball> balls;

	public boolean addBall(Ball ball) {}
}
