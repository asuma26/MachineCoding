package com.codemate.cric.enums;

public enum RunType {
	NORMAL,
	FOUR,
	SIX,
	LEG_BYE,
	BYE,
	NO_BALL,
	OVERTHROW
}
