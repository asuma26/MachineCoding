package com.codemate.cric.enums;

public enum WicketType {
	  BOLD,
	  CAUGHT,
	  STUMPED,
	  RUN_OUT,
	  LBW,
	  RETIRED_HURT,
	  HIT_WICKET,
	  OBSTRUCTING
}
