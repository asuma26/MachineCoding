package com.codemate.cric.teamdetails;

import java.util.List;

import com.codemate.cric.users.Player;

public class Playing11 {
	private List<Player> players;
	private Player twelfthMan;

	public boolean addPlayer(Player player) {
		
	}
}
