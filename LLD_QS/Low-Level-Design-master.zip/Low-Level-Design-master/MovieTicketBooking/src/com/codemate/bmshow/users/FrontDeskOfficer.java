package com.codemate.bmshow.users;

public class FrontDeskOfficer extends Person {
	public boolean createBooking(Booking booking);
}
