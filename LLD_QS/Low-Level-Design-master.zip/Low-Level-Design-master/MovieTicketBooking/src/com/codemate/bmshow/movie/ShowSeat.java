package com.codemate.bmshow.movie;

public class ShowSeat extends CinemaHallSeat{
	  private int showSeatId;
	  private boolean isReserved;
	  private double price;
}