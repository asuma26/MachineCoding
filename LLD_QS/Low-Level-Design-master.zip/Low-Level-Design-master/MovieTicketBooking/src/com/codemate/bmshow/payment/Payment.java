package com.codemate.bmshow.payment;

import java.util.Date;

import com.codemate.bmshow.enums.PaymentStatus;

public class Payment {
	  private double amount;
	  private Date createdOn;
	  private int transactionId;
	  private PaymentStatus status;	
}
