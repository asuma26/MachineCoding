package com.codemate.bmshow.enums;

public enum SeatType {
	  REGULAR, 
	  PREMIUM, 
	  ACCESSIBLE, 
	  SHIPPED, 
	  EMERGENCY_EXIT, 
	  OTHER
}
