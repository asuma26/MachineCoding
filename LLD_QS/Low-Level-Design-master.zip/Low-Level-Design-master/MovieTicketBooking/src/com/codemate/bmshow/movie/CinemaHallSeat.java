package com.codemate.bmshow.movie;

import com.codemate.bmshow.enums.SeatType;

public class CinemaHallSeat {
	private int seatRow;
	private int seatColumn;
	private SeatType seatType;
}
