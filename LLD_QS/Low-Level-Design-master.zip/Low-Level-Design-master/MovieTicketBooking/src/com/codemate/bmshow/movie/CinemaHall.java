package com.codemate.bmshow.movie;

public class CinemaHall {
	  private String name;
	  private int totalSeats;

	  private List<CinemaHallSeat> seats;
	  private List<Show> shows;

}
