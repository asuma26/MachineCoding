package com.codemate.bmshow.users;

public class Customer extends Person {
	  public boolean makeBooking(Booking booking);
	  public List<Booking> getBookings();
}