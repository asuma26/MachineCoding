package com.codemate.bmshow.movie;

public class City {
	
	  private String name;
	  private String state;
	  private String zipCode;

}
