package com.codemate.bmshow.users;

public class Guest {
	  public bool registerAccount();
}