package com.codemate.bmshow.movie;

public class Show {
	  private int showId;
	  private Date createdOn;
	  private Date startTime;
	  private Date endTime;
	  private CinemaHall playedAt;
	  private Movie movie;

}
