package com.codemate.bmshow.movie;

public class Cinema {
	  private String name;
	  private int totalCinemaHalls;
	  private Address location;

	  private List<CinemaHall> halls;
}
