package com.mayank.fooddelivery.model;

public enum  PaymentStatus {
    PENDING,
    APPROVED,
    DECLINED,
    TIMEOUT
}
