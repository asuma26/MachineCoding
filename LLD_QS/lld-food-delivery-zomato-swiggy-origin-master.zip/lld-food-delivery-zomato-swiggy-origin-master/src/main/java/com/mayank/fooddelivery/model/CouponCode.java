package com.mayank.fooddelivery.model;

public enum CouponCode {
    TWENTY_PERCENT_OFF,
    FIVE_HUNDRED_OFF
}
