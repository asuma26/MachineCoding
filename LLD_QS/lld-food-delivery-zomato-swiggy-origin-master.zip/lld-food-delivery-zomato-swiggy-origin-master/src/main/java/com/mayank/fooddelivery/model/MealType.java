package com.mayank.fooddelivery.model;

public enum MealType {
    BREAKFAST,
    BRUNCH,
    ELEVENSES,
    LUNCH,
    DINNER,
    SUPPER,
    AFTERNOON_TEA,
    HIGH_TEA
}
