package com.mayank.fooddelivery.model;

public enum CartCommandType {
    ADD_ITEM,
    REMOVE_ITEM,
    CLEAR_CART
}
