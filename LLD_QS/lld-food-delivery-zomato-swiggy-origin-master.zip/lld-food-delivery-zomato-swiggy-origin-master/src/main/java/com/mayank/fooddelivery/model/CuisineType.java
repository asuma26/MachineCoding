package com.mayank.fooddelivery.model;

public enum CuisineType {
    INDIAN_CUISINE,
    INDIAN_CHINESE,
    ITALIAN_CUISINE,
    ITALIAN_AMERICAN,
    CHINESE_CUISINE,
    GUJARATI,
    HYDERABAD,
    JAPANESE,
    SOUTH_INDIAN,
    KOREAN
}
