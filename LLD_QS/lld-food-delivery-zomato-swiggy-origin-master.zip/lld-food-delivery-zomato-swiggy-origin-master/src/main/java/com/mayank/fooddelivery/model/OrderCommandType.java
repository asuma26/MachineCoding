package com.mayank.fooddelivery.model;

public enum OrderCommandType {
    PLACE,
    CANCEL
}
