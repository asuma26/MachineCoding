package com.mayank.fooddelivery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodDeliveryStartApplication {
    public static void main(String[] args) {
        SpringApplication.run(FoodDeliveryStartApplication.class, args);
    }
}
