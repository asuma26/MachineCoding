package com.gb.reviews.review;

public enum ReviewSentiment {
    POSITIVE,
    CRITICAL,
    DETAILED,
    GENERAL
}
