package com.gb.reviews.review;

public enum ReviewState {
    MODERATION_SUCCESS,
    MODERATION_PENDING,
    MODERATION_FAILED
}
