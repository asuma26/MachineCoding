package com.gb.reviews.summary;

import lombok.Getter;

@Getter
public class ReviewSummary extends Summary {

}
