package com.gb.reviews.notifier;

public enum NotificationState {
    SUCCESS,
    FAILED
}
