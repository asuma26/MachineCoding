package com.gb.reviews.user;

public enum VerificationStatus {
    VERIFIED,
    NON_VERFIFIED,
    BLACK_LISTED,
}
