package com.gb.reviews.review;

public enum ReviewType {
    CERTIFIED_BUYER,
    ANONYMOUS
}
