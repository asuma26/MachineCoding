package com.gb.reviews.summary;

public class FeatureSummary extends Summary {

}
