package com.uditagarwal.api;

import static org.junit.jupiter.api.Assertions.*;

class BookingControllerTest {

}