package com.uditagarwal.model;

public enum BookingStatus {
    Created,
    Confirmed,
    Expired
}

