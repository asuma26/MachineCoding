package com.uditagarwal.exceptions;

public class AlreadyExistsException extends RuntimeException {
}
