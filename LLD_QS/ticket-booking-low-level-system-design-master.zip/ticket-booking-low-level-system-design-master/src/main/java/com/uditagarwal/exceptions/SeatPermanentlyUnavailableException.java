package com.uditagarwal.exceptions;

public class SeatPermanentlyUnavailableException extends RuntimeException {
}
