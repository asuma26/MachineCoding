package com.uditagarwal.exceptions;

public class BadRequestException extends RuntimeException {
}
