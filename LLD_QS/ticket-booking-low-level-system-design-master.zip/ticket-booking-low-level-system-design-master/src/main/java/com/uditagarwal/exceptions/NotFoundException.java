package com.uditagarwal.exceptions;

public class NotFoundException extends RuntimeException {

}
