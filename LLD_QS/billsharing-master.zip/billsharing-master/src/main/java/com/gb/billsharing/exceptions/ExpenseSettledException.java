package com.gb.billsharing.exceptions;

public class ExpenseSettledException extends Exception {
    public ExpenseSettledException(String s) {
        super(s);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
