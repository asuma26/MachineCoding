package com.gb.amazonlocker.exception;

public class PackPickTimeExceededException extends Exception {
    public PackPickTimeExceededException(String message) {
        super(message);
    }
}
