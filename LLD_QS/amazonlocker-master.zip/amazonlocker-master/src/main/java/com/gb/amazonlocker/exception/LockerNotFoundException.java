package com.gb.amazonlocker.exception;

public class LockerNotFoundException extends Exception {
    public LockerNotFoundException(String message) {
        super(message);
    }
}
