package com.gb.amazonlocker.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Item {
    private String id;
    private int quantity;
}
