package com.gb.amazonlocker.exception;

public class LockeCodeMisMatchException extends Exception {
    public LockeCodeMisMatchException(String message) {
        super(message);
    }
}
