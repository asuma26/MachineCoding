package com.gb.amazonlocker.repository;

import com.gb.amazonlocker.model.Notification;

import java.util.HashMap;
import java.util.Map;

public class NotificationRepository {
    public static Map<String, Notification> notificationMap = new HashMap<>();
}
