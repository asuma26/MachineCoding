package com.gb.amazonlocker.model;

public enum LockerSize {
    XS,
    S,
    M,
    L,
    XL,
    XXL
}
