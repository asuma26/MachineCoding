package com.gb.amazonlocker.model;

public enum  LockerStatus {
    CLOSED,
    BOOKED,
    AVAILALBE,
    NOTOPENED,
    OPEN
}
