package com.gb.amazonlocker;

public class AmazonLockerMain {
    public static void main(String[] args) {

    }
}
