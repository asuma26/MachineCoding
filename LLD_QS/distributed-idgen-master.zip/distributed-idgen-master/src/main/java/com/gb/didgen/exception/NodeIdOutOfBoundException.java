package com.gb.didgen.exception;

public class NodeIdOutOfBoundException extends Exception {
    public NodeIdOutOfBoundException(String message) {
        super(message);
    }
}
