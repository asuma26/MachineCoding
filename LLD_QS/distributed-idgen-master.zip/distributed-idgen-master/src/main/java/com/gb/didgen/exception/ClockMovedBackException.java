package com.gb.didgen.exception;

public class ClockMovedBackException extends Exception {
    public ClockMovedBackException(String message) {
        super(message);
    }
}
