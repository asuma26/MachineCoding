package com.gb.didgen.service;

public interface IdGenerator {
    String generateId();
}
