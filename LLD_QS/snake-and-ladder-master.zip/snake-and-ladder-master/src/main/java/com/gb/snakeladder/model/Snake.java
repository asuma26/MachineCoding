package com.gb.snakeladder.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Snake {
    private int head;
    private int tail;
}
