package com.gb.truecaller.exception;

public class ContactsExceededException extends Exception {
    public ContactsExceededException(String message) {
        super(message);
    }
}
