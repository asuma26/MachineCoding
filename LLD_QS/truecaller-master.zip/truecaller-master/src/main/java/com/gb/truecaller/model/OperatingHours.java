package com.gb.truecaller.model;

import java.time.LocalTime;

public class OperatingHours {
    private LocalTime openingTime;
    private LocalTime closingTime;
}
