package com.gb.truecaller.model.common;

public enum Gender {
    FEMALE,
    MALE,
    TRANSGENDER
}
