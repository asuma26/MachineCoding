package com.gb.truecaller.model.common;

public enum SocialProfileType {
    FACEBOOK,
    TWITTER,
    LINKEDIN,
    WEBSITE
}
