package com.gb.truecaller.model;

public enum UserCategory {
    FREE,
    GOLD,
    PLATINUM
}
